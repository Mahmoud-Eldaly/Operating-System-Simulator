public class M_WB {
    int MemToReg;
    int readData;
    int ALU_result;
//    int pc;
    int RegWrite;
    int RegDst;
    int WriteRegister;
    int jump,Branch,jumpAddress;
    int zeroFlag;
    int AddedPC;
    int instNo;
    int MemRead;
}
