public class EX_M {
    int MemToReg;
    int WriteData;
    int ALU_result;
    int PC,AddedPC;
    int WriteRegister;

    int MemRead;
    int MemWrite;
    int ZeroFlag;
    int Branch;
    int RegWrite;
    int RegDst;
    int jump;
    int jumpAddress;
    int instNo;


}
